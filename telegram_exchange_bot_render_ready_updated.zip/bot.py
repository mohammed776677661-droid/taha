import asyncio
import os
from aiohttp import web
import aiosqlite
from dotenv import load_dotenv

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
PORT = int(os.getenv("PORT", "10000"))
WEBHOOK_BASE_URL = os.getenv("WEBHOOK_BASE_URL", "").rstrip("/")
WEBHOOK_PATH = os.getenv("WEBHOOK_PATH", "/webhook")
DB_PATH = os.getenv("DB_PATH", "bot.db")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing")
if not WEBHOOK_BASE_URL:
    raise RuntimeError("WEBHOOK_BASE_URL is missing")

bot = Bot(BOT_TOKEN)
dp = Dispatcher()


async def db():
    return await aiosqlite.connect(DB_PATH)


async def init_db():
    conn = await db()
    await conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        full_name TEXT NOT NULL,
        points INTEGER DEFAULT 0,
        referrals INTEGER DEFAULT 0,
        referred_by INTEGER,
        banned INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS channels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER NOT NULL,
        chat_id TEXT NOT NULL UNIQUE,
        username TEXT,
        title TEXT NOT NULL,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel_id INTEGER NOT NULL,
        reward INTEGER DEFAULT 1,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS completions (
        user_id INTEGER NOT NULL,
        task_id INTEGER NOT NULL,
        completed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, task_id)
    );

    CREATE TABLE IF NOT EXISTS campaigns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL,
        target INTEGER NOT NULL,
        current INTEGER DEFAULT 0,
        cost_per_user INTEGER DEFAULT 1,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        reason TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """)
    await conn.commit()
    await conn.close()


async def ensure_user(user_id, username, full_name, referrer_id=None):
    conn = await db()
    await conn.execute("""
        INSERT INTO users(id, username, full_name)
        VALUES(?,?,?)
        ON CONFLICT(id) DO UPDATE SET
            username=excluded.username,
            full_name=excluded.full_name
    """, (user_id, username, full_name))

    if referrer_id and referrer_id != user_id:
        cur = await conn.execute(
            "SELECT referred_by FROM users WHERE id=?", (user_id,)
        )
        row = await cur.fetchone()
        if row and row[0] is None:
            cur2 = await conn.execute(
                "SELECT id FROM users WHERE id=?", (referrer_id,)
            )
            if await cur2.fetchone():
                await conn.execute(
                    "UPDATE users SET referred_by=? WHERE id=?",
                    (referrer_id, user_id)
                )
                await conn.execute(
                    "UPDATE users SET referrals=referrals+1, points=points+20 WHERE id=?",
                    (referrer_id,)
                )
                await conn.execute(
                    "INSERT INTO transactions(user_id,amount,reason) VALUES(?,?,?)",
                    (referrer_id, 20, "مكافأة إحالة")
                )
    await conn.commit()
    await conn.close()


async def get_user(user_id):
    conn = await db()
    conn.row_factory = aiosqlite.Row
    cur = await conn.execute("SELECT * FROM users WHERE id=?", (user_id,))
    row = await cur.fetchone()
    await conn.close()
    return row


async def add_points(user_id, amount, reason):
    conn = await db()
    await conn.execute(
        "UPDATE users SET points=points+? WHERE id=?", (amount, user_id)
    )
    await conn.execute(
        "INSERT INTO transactions(user_id,amount,reason) VALUES(?,?,?)",
        (user_id, amount, reason)
    )
    await conn.commit()
    await conn.close()


async def spend_points(user_id, amount, reason):
    conn = await db()
    cur = await conn.execute(
        "UPDATE users SET points=points-? WHERE id=? AND points>=?",
        (amount, user_id, amount)
    )
    if cur.rowcount == 0:
        await conn.rollback()
        await conn.close()
        return False
    await conn.execute(
        "INSERT INTO transactions(user_id,amount,reason) VALUES(?,?,?)",
        (user_id, -amount, reason)
    )
    await conn.commit()
    await conn.close()
    return True


async def add_channel(owner_id, chat_id, username, title):
    conn = await db()
    try:
        cur = await conn.execute(
            "INSERT INTO channels(owner_id,chat_id,username,title) VALUES(?,?,?,?)",
            (owner_id, str(chat_id), username, title)
        )
        channel_id = cur.lastrowid
        await conn.execute(
            "INSERT INTO tasks(channel_id,reward) VALUES(?,1)", (channel_id,)
        )
        await conn.commit()
        await conn.close()
        return channel_id
    except aiosqlite.IntegrityError:
        await conn.close()
        return None


async def list_user_channels(owner_id):
    conn = await db()
    conn.row_factory = aiosqlite.Row
    cur = await conn.execute(
        "SELECT * FROM channels WHERE owner_id=? ORDER BY id DESC", (owner_id,)
    )
    rows = await cur.fetchall()
    await conn.close()
    return rows


async def get_active_task_for_user(user_id):
    conn = await db()
    conn.row_factory = aiosqlite.Row
    cur = await conn.execute("""
        SELECT t.*, c.chat_id, c.username, c.title
        FROM tasks t
        JOIN channels c ON c.id=t.channel_id
        WHERE t.active=1 AND c.active=1
          AND t.id NOT IN (
              SELECT task_id FROM completions WHERE user_id=?
          )
        ORDER BY t.id ASC LIMIT 1
    """, (user_id,))
    row = await cur.fetchone()
    await conn.close()
    return row


async def complete_task(user_id, task_id):
    conn = await db()
    try:
        cur = await conn.execute(
            "SELECT reward FROM tasks WHERE id=? AND active=1", (task_id,)
        )
        row = await cur.fetchone()
        if not row:
            await conn.close()
            return None

        await conn.execute(
            "INSERT INTO completions(user_id,task_id) VALUES(?,?)",
            (user_id, task_id)
        )
        reward = row[0]
        await conn.execute(
            "UPDATE users SET points=points+? WHERE id=?", (reward, user_id)
        )
        await conn.execute(
            "INSERT INTO transactions(user_id,amount,reason) VALUES(?,?,?)",
            (user_id, reward, f"إكمال مهمة #{task_id}")
        )
        await conn.commit()
        await conn.close()
        return reward
    except aiosqlite.IntegrityError:
        await conn.close()
        return False


async def create_campaign(owner_id, channel_id, target, cost):
    total = target * cost
    if not await spend_points(owner_id, total, f"إنشاء حملة للقناة #{channel_id}"):
        return False

    conn = await db()
    await conn.execute(
        "INSERT INTO campaigns(owner_id,channel_id,target,cost_per_user) VALUES(?,?,?,?)",
        (owner_id, channel_id, target, cost)
    )
    await conn.commit()
    await conn.close()
    return True


async def stats():
    conn = await db()
    users = (await (await conn.execute(
        "SELECT COUNT(*) FROM users")).fetchone())[0]
    channels = (await (await conn.execute(
        "SELECT COUNT(*) FROM channels WHERE active=1")).fetchone())[0]
    campaigns = (await (await conn.execute(
        "SELECT COUNT(*) FROM campaigns WHERE active=1")).fetchone())[0]
    await conn.close()
    return users, channels, campaigns


def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📺 مهام الاشتراك", callback_data="tasks")],
        [InlineKeyboardButton(text="➕ إضافة قناتي", callback_data="add_channel")],
        [InlineKeyboardButton(text="🚀 إنشاء حملة", callback_data="campaign")],
        [InlineKeyboardButton(text="💰 رصيدي", callback_data="balance")],
        [InlineKeyboardButton(text="👥 رابط الإحالة", callback_data="referral")],
    ])


def task_keyboard(url, task_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 فتح القناة", url=url)],
        [InlineKeyboardButton(text="✅ تحقق من الاشتراك", callback_data=f"verify:{task_id}")],
        [InlineKeyboardButton(text="🔄 مهمة أخرى", callback_data="tasks")]
    ])


def is_admin(message):
    return message.from_user.id == ADMIN_ID


@dp.message(CommandStart())
async def start(message: Message):
    referrer_id = None
    args = (message.text or "").split(maxsplit=1)
    if len(args) == 2 and args[1].startswith("ref_"):
        try:
            referrer_id = int(args[1][4:])
        except ValueError:
            pass

    await ensure_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.full_name,
        referrer_id
    )
    user = await get_user(message.from_user.id)

    if user["banned"]:
        await message.answer("🚫 حسابك محظور من استخدام البوت.")
        return

    await message.answer(
        f"👋 أهلاً بك {message.from_user.full_name}!\n\n"
        f"💰 رصيدك: {user['points']} نقطة\n\n"
        "اختر من القائمة:",
        reply_markup=main_menu()
    )


@dp.callback_query(F.data == "balance")
async def balance(call: CallbackQuery):
    user = await get_user(call.from_user.id)
    await call.message.edit_text(
        f"💰 رصيدك الحالي: {user['points']} نقطة\n\n"
        f"👥 الإحالات: {user['referrals']}",
        reply_markup=main_menu()
    )
    await call.answer()


@dp.callback_query(F.data == "referral")
async def referral(call: CallbackQuery):
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start=ref_{call.from_user.id}"
    await call.message.edit_text(
        f"👥 رابط الإحالة الخاص بك:\n\n{link}\n\n"
        "شارك الرابط مع أصدقائك لتحصل على 20 نقطة لكل مستخدم جديد.",
        reply_markup=main_menu()
    )
    await call.answer()


@dp.callback_query(F.data == "tasks")
async def tasks(call: CallbackQuery):
    user = await get_user(call.from_user.id)
    if not user or user["banned"]:
        await call.answer("الحساب غير متاح.", show_alert=True)
        return

    task = await get_active_task_for_user(call.from_user.id)
    if not task:
        await call.message.edit_text(
            "📭 لا توجد مهام متاحة حالياً.",
            reply_markup=main_menu()
        )
        await call.answer()
        return

    username = task["username"]
    if not username:
        await call.message.edit_text(
            "⚠️ هذه القناة لا تملك معرفاً عاماً. اطلب من الإدارة ضبطها.",
            reply_markup=main_menu()
        )
        await call.answer()
        return

    url = f"https://t.me/{username.lstrip('@')}"
    await call.message.edit_text(
        f"📢 اشترك في القناة:\n\n{task['title']}\n\n"
        f"🎁 المكافأة: {task['reward']} نقطة",
        reply_markup=task_keyboard(url, task["id"])
    )
    await call.answer()


@dp.callback_query(F.data.startswith("verify:"))
async def verify(call: CallbackQuery):
    try:
        task_id = int(call.data.split(":")[1])
    except (ValueError, IndexError):
        await call.answer("مهمة غير صحيحة.", show_alert=True)
        return

    task = await get_active_task_for_user(call.from_user.id)
    if not task or task["id"] != task_id:
        await call.answer("هذه المهمة لم تعد متاحة.", show_alert=True)
        return

    try:
        member = await bot.get_chat_member(task["chat_id"], call.from_user.id)
        if member.status not in ("member", "administrator", "creator"):
            await call.answer(
                "❌ لم يتم العثور على اشتراكك في القناة.",
                show_alert=True
            )
            return
    except TelegramBadRequest:
        await call.answer(
            "⚠️ تعذر التحقق. يجب أن يكون البوت داخل القناة وبالصلاحيات المناسبة.",
            show_alert=True
        )
        return

    reward = await complete_task(call.from_user.id, task_id)
    if reward is False or reward is None:
        await call.answer(
            "تم احتساب هذه المهمة مسبقاً أو لم تعد متاحة.",
            show_alert=True
        )
        return

    await call.message.edit_text(
        f"✅ تم التحقق بنجاح!\n\n🎁 حصلت على {reward} نقطة.",
        reply_markup=main_menu()
    )
    await call.answer("تمت إضافة النقاط.")


@dp.callback_query(F.data == "add_channel")
async def add_channel_help(call: CallbackQuery):
    await call.message.edit_text(
        "➕ لإضافة قناتك، أرسل:\n\n"
        "/addchannel @channel_username\n\n"
        "يجب أن يكون البوت مشرفاً داخل القناة.",
        reply_markup=main_menu()
    )
    await call.answer()


@dp.message(Command("addchannel"))
async def addchannel(message: Message):
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("الاستخدام: /addchannel @channel_username")
        return

    username = parts[1].strip()
    if not username.startswith("@"):
        username = "@" + username

    try:
        chat = await bot.get_chat(username)
        me = await bot.get_me()
        member = await bot.get_chat_member(chat.id, me.id)

        if member.status not in ("administrator", "creator"):
            await message.answer("❌ يجب أن يكون البوت مشرفاً في القناة.")
            return

        channel_id = await add_channel(
            message.from_user.id,
            chat.id,
            chat.username,
            chat.title or username
        )

        if not channel_id:
            await message.answer("⚠️ هذه القناة مضافة مسبقاً.")
            return

        await message.answer(
            f"✅ تمت إضافة القناة: {chat.title}\n"
            "تم إنشاء مهمة تبادل تلقائياً بمكافأة نقطة واحدة."
        )
    except TelegramBadRequest:
        await message.answer(
            "❌ تعذر الوصول إلى القناة. تأكد من المعرف وأن البوت مشرف فيها."
        )


@dp.callback_query(F.data == "campaign")
async def campaign_help(call: CallbackQuery):
    channels = await list_user_channels(call.from_user.id)
    if not channels:
        await call.message.edit_text(
            "أضف قناة أولاً عبر:\n/addchannel @channel_username",
            reply_markup=main_menu()
        )
        await call.answer()
        return

    text = "🚀 إنشاء حملة:\n\n"
    for c in channels:
        text += f"#{c['id']} — {c['title']}\n"

    text += (
        "\nاستخدم:\n"
        "/campaign رقم_القناة عدد_المشتركين تكلفة_المشترك\n\n"
        "مثال:\n/campaign 1 100 1"
    )
    await call.message.edit_text(text, reply_markup=main_menu())
    await call.answer()


@dp.message(Command("campaign"))
async def campaign(message: Message):
    parts = (message.text or "").split()
    if len(parts) != 4:
        await message.answer("الاستخدام: /campaign channel_id target cost")
        return

    try:
        channel_id, target, cost = map(int, parts[1:])
    except ValueError:
        await message.answer("❌ الأرقام غير صحيحة.")
        return

    channels = await list_user_channels(message.from_user.id)
    if not any(c["id"] == channel_id for c in channels):
        await message.answer("❌ هذه القناة ليست ضمن قنواتك.")
        return

    if target <= 0 or cost <= 0:
        await message.answer("❌ يجب أن تكون القيم أكبر من صفر.")
        return

    ok = await create_campaign(
        message.from_user.id, channel_id, target, cost
    )
    if not ok:
        user = await get_user(message.from_user.id)
        await message.answer(
            f"❌ رصيدك غير كافٍ.\n"
            f"رصيدك: {user['points']} نقطة\n"
            f"المطلوب: {target * cost} نقطة"
        )
        return

    await message.answer(
        "✅ تم إنشاء الحملة.\n"
        f"🎯 الهدف: {target}\n"
        f"💰 التكلفة: {target * cost} نقطة"
    )


@dp.message(Command("admin"))
async def admin(message: Message):
    if not is_admin(message):
        return
    users, channels, campaigns = await stats()
    await message.answer(
        "🛠 لوحة الإدارة\n\n"
        f"👥 المستخدمون: {users}\n"
        f"📺 القنوات النشطة: {channels}\n"
        f"🚀 الحملات النشطة: {campaigns}\n\n"
        "الأوامر:\n"
        "/user ID\n"
        "/addpoints ID AMOUNT\n"
        "/delpoints ID AMOUNT\n"
        "/stats"
    )


@dp.message(Command("stats"))
async def admin_stats(message: Message):
    if not is_admin(message):
        return
    users, channels, campaigns = await stats()
    await message.answer(
        "📊 الإحصائيات\n\n"
        f"المستخدمون: {users}\n"
        f"القنوات: {channels}\n"
        f"الحملات: {campaigns}"
    )


@dp.message(Command("user"))
async def admin_user(message: Message):
    if not is_admin(message):
        return
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("الاستخدام: /user ID")
        return

    user = await get_user(int(parts[1]))
    if not user:
        await message.answer("المستخدم غير موجود.")
        return

    await message.answer(
        "👤 المستخدم\n"
        f"ID: {user['id']}\n"
        f"Username: @{user['username'] or '-'}\n"
        f"الاسم: {user['full_name']}\n"
        f"النقاط: {user['points']}\n"
        f"الإحالات: {user['referrals']}\n"
        f"محظور: {'نعم' if user['banned'] else 'لا'}"
    )


@dp.message(Command("addpoints"))
async def admin_addpoints(message: Message):
    if not is_admin(message):
        return
    parts = (message.text or "").split()
    if len(parts) != 3:
        await message.answer("الاستخدام: /addpoints ID AMOUNT")
        return

    try:
        uid, amount = int(parts[1]), int(parts[2])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ قيم غير صحيحة.")
        return

    if not await get_user(uid):
        await message.answer("المستخدم غير موجود.")
        return

    await add_points(uid, amount, "إضافة من الإدارة")
    await message.answer("✅ تمت إضافة النقاط.")


@dp.message(Command("delpoints"))
async def admin_delpoints(message: Message):
    if not is_admin(message):
        return
    parts = (message.text or "").split()
    if len(parts) != 3:
        await message.answer("الاستخدام: /delpoints ID AMOUNT")
        return

    try:
        uid, amount = int(parts[1]), int(parts[2])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ قيم غير صحيحة.")
        return

    if not await get_user(uid):
        await message.answer("المستخدم غير موجود.")
        return

    ok = await spend_points(uid, amount, "خصم من الإدارة")
    await message.answer(
        "✅ تم الخصم." if ok else "❌ رصيد المستخدم غير كافٍ."
    )


async def on_startup(app):
    await init_db()
    await bot.set_webhook(
        url=WEBHOOK_BASE_URL + WEBHOOK_PATH,
        allowed_updates=dp.resolve_used_update_types(),
        drop_pending_updates=True
    )


async def on_shutdown(app):
    await bot.delete_webhook(drop_pending_updates=False)
    await bot.session.close()


async def health(request):
    return web.Response(text="Telegram Exchange Bot is running")


def create_app():
    app = web.Application()
    app.router.add_get("/", health)

    SimpleRequestHandler(
        dispatcher=dp,
        bot=bot
    ).register(app, path=WEBHOOK_PATH)

    setup_application(app, dp, bot=bot)
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    return app


if __name__ == "__main__":
    web.run_app(create_app(), host="0.0.0.0", port=PORT)
