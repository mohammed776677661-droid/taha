# Telegram Exchange Bot - Render Ready

بوت تبادل قنوات تيليجرام بنظام النقاط.

## Render
Build Command:
pip install -r requirements.txt

Start Command:
python bot.py

Environment Variables:
BOT_TOKEN=توكن البوت الجديد
ADMIN_ID=1792685788
WEBHOOK_BASE_URL=https://اسم-الخدمة.onrender.com

PORT يتم توفيره تلقائياً من Render.

## مهم
يجب إضافة البوت كمشرف في القنوات التي تريد إضافتها.
لا تضع BOT_TOKEN داخل GitHub أو ترسله لأي شخص.
SQLite على التخزين المجاني في Render قد يفقد البيانات عند بعض عمليات إعادة التشغيل/إعادة النشر.
